@echo off
setlocal
cd /d "%~dp0backend"
echo ========================================
echo   WFH Monitor - Backend Starter
echo ========================================
where node >nul 2>nul
if errorlevel 1 (
  echo ERROR: Node.js is not installed. Install Node.js 20 or newer first.
  pause
  exit /b 1
)
if not exist ".env" (
  echo ERROR: backend\.env is missing.
  echo Copy .env.example to .env, then set JWT_SECRET and MongoDB settings.
  pause
  exit /b 1
)
if not exist "node_modules" (
  echo Installing project dependencies...
  call npm.cmd install
  if errorlevel 1 (
    echo ERROR: npm install failed.
    pause
    exit /b 1
  )
)
echo Starting WFH Monitor. Keep this window open while using the app.
call npm.cmd start
pause
