import User from "../models/User.js";
import WorkSession from "../models/WorkSession.js";
import asyncHandler from "../utils/asyncHandler.js";
import AppError from "../utils/AppError.js";
import { toPublicUser } from "../utils/userSerializer.js";
import { parse } from "../validators/authValidator.js";
import { statusSchema, locationSchema } from "../validators/userValidator.js";
import { emitToAdmins, updateUserStatus, isConnected } from "../sockets/index.js";

// GET /api/users  (admin only) -> all employees
export const getUsers = asyncHandler(async (req, res) => {
  const users = await User.find({ role: "employee" }).sort({ name: 1 });
  res.json({ success: true, count: users.length, users: users.map(toPublicUser) });
});

// PATCH /api/users/status  (employee) -> fallback to the socket events
export const updateStatus = asyncHandler(async (req, res) => {
  if (req.user.role !== "employee") throw new AppError("Only employees have an activity status", 403);
  const { status } = parse(statusSchema, req.body);
  // Without a live socket nothing would ever set the user back to offline, so refuse.
  if (!isConnected(String(req.user._id))) {
    throw new AppError("No live connection found. Open your dashboard first.", 409);
  }
  const user = await updateUserStatus(req.app.get("io"), String(req.user._id), status, {
    touchActivity: status === "online",
  });
  res.json({ success: true, user: toPublicUser(user) });
});

// PATCH /api/users/location  (employee) -> only with consent
export const updateLocation = asyncHandler(async (req, res) => {
  if (req.user.role !== "employee") throw new AppError("Only employees can share location", 403);
  const data = parse(locationSchema, req.body);

  const update = data.consent
    ? {
        $set: {
          locationConsent: true,
          location: { latitude: data.latitude, longitude: data.longitude, updatedAt: new Date() },
        },
      }
    : { $set: { locationConsent: false }, $unset: { location: "" } }; // withdraw consent => delete location

  const user = await User.findByIdAndUpdate(req.user._id, update, { new: true, runValidators: true });
  emitToAdmins(req.app.get("io"), "status:changed", toPublicUser(user));
  res.json({ success: true, user: toPublicUser(user) });
});


// GET /api/users/sessions (admin only): recent session history, newest first.
export const getSessions = asyncHandler(async (req, res) => {
  const limit = Math.min(Math.max(Number.parseInt(req.query.limit || "100", 10) || 100, 1), 500);
  const sessions = await WorkSession.find()
    .sort({ startedAt: -1 })
    .limit(limit)
    .populate("user", "name email role")
    .lean();
  const now = Date.now();
  res.json({ success: true, sessions: sessions.map((s) => ({
    id: String(s._id),
    userId: s.user ? String(s.user._id) : "",
    name: s.user?.name || "Deleted user",
    email: s.user?.email || "",
    startedAt: s.startedAt,
    endedAt: s.endedAt,
    durationSeconds: s.endedAt ? s.durationSeconds : Math.max(0, Math.floor((now - new Date(s.startedAt).getTime()) / 1000)),
    endReason: s.endReason,
    active: !s.endedAt,
  })) });
});
