// Run:  npm test      (uses Node's built-in test runner, no extra packages needed)
import test from "node:test";
import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import { computeStatusPatch, closeForRestart } from "../utils/statusTime.js";
import { runExclusive } from "../utils/keyedMutex.js";

const t = (s) => new Date(`2026-10-13T${s}Z`);
const SEC = 1000;
const MIN = 60 * SEC;

test("new user (offline since registration) -> online: offline time is counted", () => {
  const user = { status: "offline", createdAt: t("08:00:00") };
  const patch = computeStatusPatch(user, "online", t("08:10:00"), { touchActivity: true });
  assert.equal(patch["timeTotalsMs.offline"], 10 * MIN);
  assert.equal(patch.status, "online");
  assert.deepEqual(patch.statusUpdatedAt, t("08:10:00"));
  assert.deepEqual(patch.lastActivity, t("08:10:00"));
});

test("online -> inactive adds the finished online segment to existing totals", () => {
  const user = { status: "online", statusUpdatedAt: t("09:00:00"), timeTotalsMs: { online: 5 * MIN, inactive: 0, offline: 0 } };
  const patch = computeStatusPatch(user, "inactive", t("09:30:00"));
  assert.equal(patch["timeTotalsMs.online"], 35 * MIN);
  assert.equal(patch.status, "inactive");
});

test("same status (heartbeat) only touches lastActivity: totals and segment start stay", () => {
  const user = { status: "online", statusUpdatedAt: t("09:00:00") };
  const patch = computeStatusPatch(user, "online", t("09:00:30"), { touchActivity: true });
  assert.deepEqual(Object.keys(patch), ["lastActivity"]);
  assert.deepEqual(computeStatusPatch(user, "online", t("09:01:00")), {}); // nothing at all
});

test("a full day adds up: offline + online + inactive + online", () => {
  let u = { status: "offline", createdAt: t("00:00:00"), timeTotalsMs: {} };
  const apply = (next, at) => {
    const p = computeStatusPatch(u, next, t(at));
    u = { ...u, status: p.status ?? u.status, statusUpdatedAt: p.statusUpdatedAt ?? u.statusUpdatedAt,
      timeTotalsMs: { ...u.timeTotalsMs,
        ...Object.fromEntries(Object.entries(p).filter(([k]) => k.startsWith("timeTotalsMs.")).map(([k, v]) => [k.split(".")[1], v])) } };
  };
  apply("online", "09:00:00");   // offline 9h
  apply("inactive", "10:00:00"); // online 1h
  apply("online", "10:15:00");   // inactive 15m
  apply("offline", "12:00:00");  // online +1h45m
  assert.equal(u.timeTotalsMs.offline, 9 * 3600 * SEC);
  assert.equal(u.timeTotalsMs.inactive, 15 * MIN);
  assert.equal(u.timeTotalsMs.online, (1 * 60 + 105) * MIN);
});

test("clock going backwards never produces negative time", () => {
  const user = { status: "online", statusUpdatedAt: t("10:00:00") };
  assert.equal(computeStatusPatch(user, "offline", t("09:59:00"))["timeTotalsMs.online"], 0);
});

test("unknown status is rejected", () => {
  assert.throws(() => computeStatusPatch({ status: "offline" }, "busy"), /Unknown status/);
});

test("restart: online time is trusted only up to lastActivity, the rest becomes offline", () => {
  const user = { status: "online", statusUpdatedAt: t("09:00:00"), lastActivity: t("09:20:00") };
  const patch = closeForRestart(user, t("11:00:00"));
  assert.equal(patch["timeTotalsMs.online"], 20 * MIN);
  assert.equal(patch["timeTotalsMs.offline"], 100 * MIN);
  assert.equal(patch.status, "offline");
});

test("restart: already offline users are left alone", () => {
  assert.equal(closeForRestart({ status: "offline" }, t("11:00:00")), null);
});

test("runExclusive: jobs for the same key never overlap, in order", async () => {
  const log = [];
  const job = (name, ms) => async () => { log.push(`start ${name}`); await new Promise((r) => setTimeout(r, ms)); log.push(`end ${name}`); };
  await Promise.all([runExclusive("u1", job("A", 30)), runExclusive("u1", job("B", 1)), runExclusive("u2", job("C", 1))]);
  assert.ok(log.indexOf("end A") < log.indexOf("start B"), "B must wait for A");
  assert.ok(log.indexOf("start C") < log.indexOf("end A"), "other users are not blocked");
});

test("runExclusive: a failing job does not block the next one", async () => {
  await assert.rejects(runExclusive("u3", async () => { throw new Error("boom"); }), /boom/);
  assert.equal(await runExclusive("u3", async () => "still works"), "still works");
});

// ---- frontend helper (loaded from a data: URL so it works whatever the folder's module type is)
const src = readFileSync(new URL("../../frontend/js/timeUtils.js", import.meta.url), "utf8");
const { formatTotal, liveTotalMs } = await import("data:text/javascript;base64," + Buffer.from(src).toString("base64"));

test("formatTotal", () => {
  assert.equal(formatTotal(0), "0s");
  assert.equal(formatTotal(9 * SEC), "9s");
  assert.equal(formatTotal(4 * MIN + 9 * SEC), "4m 09s");
  assert.equal(formatTotal(3 * 3600 * SEC + 5 * MIN + 9 * SEC), "3h 05m 09s");
  assert.equal(formatTotal(((2 * 24 + 3) * 3600 + 5 * 60) * SEC), "2d 3h 05m");
  assert.equal(formatTotal(-5), "0s");
});

test("liveTotalMs: only the CURRENT status keeps growing; clock offset is applied", () => {
  const u = { status: "online", statusSince: t("09:00:00").toISOString(), timeTotalsMs: { online: 10 * MIN, inactive: 2 * MIN, offline: 0 } };
  const now = t("09:05:00").getTime();
  assert.equal(liveTotalMs(u, "online", now), 15 * MIN);
  assert.equal(liveTotalMs(u, "inactive", now), 2 * MIN);
  assert.equal(liveTotalMs(u, "online", now, 60 * SEC), 16 * MIN); // browser clock 1 min behind server
});
