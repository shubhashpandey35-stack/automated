import "dotenv/config"; // must be first
import http from "http";
import { Server } from "socket.io";
import app from "./app.js";
import connectDB from "./config/db.js";
import User from "./models/User.js";
import WorkSession from "./models/WorkSession.js";
import { initSocket } from "./sockets/index.js";
import { closeForRestart } from "./utils/statusTime.js";

// Stop early with a clear message if .env is incomplete
for (const key of ["MONGO_URI", "JWT_SECRET"]) {
  if (!process.env[key]) {
    console.error(`Missing ${key} in backend/.env`);
    process.exit(1);
  }
}

await connectDB();

// After a server restart no socket is connected, so nobody can be online.
// Their running time segment is closed first, so the online/inactive/offline totals stay correct.
const restartTime = new Date();
const staleUsers = await User.find({ status: { $ne: "offline" } });
for (const staleUser of staleUsers) {
  const patch = closeForRestart(staleUser, restartTime);
  if (patch) await User.updateOne({ _id: staleUser._id }, { $set: patch });
}
const openSessions = await WorkSession.find({ endedAt: null });
for (const session of openSessions) {
  session.endedAt = restartTime;
  session.durationSeconds = Math.max(0, Math.floor((restartTime.getTime() - session.startedAt.getTime()) / 1000));
  session.endReason = "server-restart";
  await session.save();
}

const PORT = process.env.PORT || 5000;
const server = http.createServer(app);

const io = new Server(server, {
  cors: {
    origin: (process.env.CLIENT_URL || "http://localhost:5000").split(",").map((s) => s.trim()),
    credentials: true,
  },
});
app.set("io", io); // controllers can reach Socket.IO via req.app.get("io")
initSocket(io);

server.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
  console.log(`Open the website: http://localhost:${PORT}/login.html`);
});
