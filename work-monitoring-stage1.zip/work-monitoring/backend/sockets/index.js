import jwt from "jsonwebtoken";
import User from "../models/User.js";
import WorkSession from "../models/WorkSession.js";
import { toPublicUser } from "../utils/userSerializer.js";
import { computeStatusPatch } from "../utils/statusTime.js";
import { runExclusive } from "../utils/keyedMutex.js";

// userId -> Set of socket ids (one employee can have several tabs open)
const connections = new Map();
// userId -> timer that will mark the user offline after a short grace period
const offlineTimers = new Map();
// One work session per user across multiple tabs.
const activeSessions = new Map();
const OFFLINE_GRACE_MS = 5000; // lets a quick page refresh / reconnect avoid flicker

export const emitToAdmins = (io, event, payload) => io.to("admins").emit(event, payload);

// Saves the status in MongoDB, adds the finished time segment to the totals,
// and pushes the result to every admin in real time.
// Jobs for the same user run one after another (see keyedMutex.js) so no time is lost.
export function updateUserStatus(io, userId, status, { touchActivity = false } = {}) {
  return runExclusive(userId, async () => {
    const user = await User.findById(userId);
    if (!user) return null;
    const patch = computeStatusPatch(user, status, new Date(), { touchActivity });
    if (Object.keys(patch).length === 0) return user; // nothing changed
    const updated = await User.findByIdAndUpdate(userId, { $set: patch }, { new: true });
    if (updated) emitToAdmins(io, "status:changed", toPublicUser(updated));
    return updated;
  });
}

// True while at least one browser tab of this employee is connected.
export const isConnected = (userId) => (connections.get(userId)?.size || 0) > 0;

// Used by logout: close every socket of the user and mark offline immediately.
export async function forceOffline(io, userId) {
  clearTimeout(offlineTimers.get(userId));
  offlineTimers.delete(userId);
  connections.delete(userId);
  await closeSession(userId, "logout");
  io.in(`user:${userId}`).disconnectSockets(true);
  return updateUserStatus(io, userId, "offline");
}

async function startSession(userId) {
  if (activeSessions.has(userId)) return;
  const session = await WorkSession.create({ user: userId, startedAt: new Date(), endReason: "active" });
  activeSessions.set(userId, String(session._id));
}

async function closeSession(userId, reason = "disconnect") {
  const sessionId = activeSessions.get(userId);
  if (!sessionId) return;
  activeSessions.delete(userId);
  const endedAt = new Date();
  const session = await WorkSession.findById(sessionId);
  if (session && !session.endedAt) {
    session.endedAt = endedAt;
    session.durationSeconds = Math.max(0, Math.floor((endedAt.getTime() - session.startedAt.getTime()) / 1000));
    session.endReason = reason;
    await session.save();
  }
}

export function initSocket(io) {
  // 1) Authenticate every socket with the JWT sent by the browser.
  io.use(async (socket, next) => {
    try {
      const token = socket.handshake.auth?.token;
      if (!token) return next(new Error("Unauthorized"));
      const decoded = jwt.verify(token, process.env.JWT_SECRET);
      const user = await User.findById(decoded.id).select("role");
      if (!user) return next(new Error("Unauthorized"));
      socket.data.userId = String(user._id);
      socket.data.role = user.role;
      next();
    } catch {
      next(new Error("Unauthorized"));
    }
  });

  // 2) Handle connections
  io.on("connection", async (socket) => {
    const { userId, role } = socket.data;
    socket.join(`user:${userId}`);

    // Admins just join the "admins" room to receive updates.
    if (role === "admin") {
      socket.join("admins");
      return;
    }

    // ---- Employee: register event handlers FIRST (synchronously) ----
    let lastActiveAt = 0;
    socket.on("activity:active", async () => {
      const now = Date.now();
      if (now - lastActiveAt < 1000) return; // basic flood protection
      lastActiveAt = now;
      try {
        await updateUserStatus(io, userId, "online", { touchActivity: true });
      } catch (err) {
        console.error("activity:active failed:", err.message);
      }
    });

    socket.on("activity:inactive", async () => {
      try {
        await updateUserStatus(io, userId, "inactive");
      } catch (err) {
        console.error("activity:inactive failed:", err.message);
      }
    });

    socket.on("disconnect", () => {
      const set = connections.get(userId);
      if (!set) return; // already handled (e.g. logout)
      set.delete(socket.id);
      if (set.size > 0) return; // other tabs are still connected

      // Last tab closed / internet lost: wait a few seconds, then mark offline.
      const timer = setTimeout(async () => {
        offlineTimers.delete(userId);
        if (connections.get(userId)?.size) return; // user reconnected meanwhile
        connections.delete(userId);
        try {
          await closeSession(userId, "disconnect");
          await updateUserStatus(io, userId, "offline");
        } catch (err) {
          console.error("offline update failed:", err.message);
        }
      }, OFFLINE_GRACE_MS);
      offlineTimers.set(userId, timer);
    });

    // ---- then mark the employee online ----
    clearTimeout(offlineTimers.get(userId));
    offlineTimers.delete(userId);
    if (!connections.has(userId)) connections.set(userId, new Set());
    const isFirstConnection = connections.get(userId).size === 0;
    connections.get(userId).add(socket.id);

    try {
      if (isFirstConnection) await startSession(userId);
      await updateUserStatus(io, userId, "online", { touchActivity: true });
    } catch (err) {
      console.error("online update failed:", err.message);
    }
  });
}
