import mongoose from "mongoose";

const workSessionSchema = new mongoose.Schema({
  user: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true, index: true },
  startedAt: { type: Date, required: true, default: Date.now, index: true },
  endedAt: { type: Date, default: null },
  durationSeconds: { type: Number, default: 0, min: 0 },
  endReason: { type: String, enum: ["logout", "disconnect", "server-restart", "active"], default: "active" },
}, { timestamps: true });
workSessionSchema.index({ user: 1, startedAt: -1 });
export default mongoose.model("WorkSession", workSessionSchema);
