// Runs async jobs one-by-one for the SAME key (e.g. one user id),
// while jobs for different keys can still run in parallel.
// Why: a socket "connect" and an "activity:active" event can arrive at almost the same
// moment. Without this, both would read the old status and one time-total would be lost.
const tails = new Map();

export function runExclusive(key, job) {
  const previous = tails.get(key) || Promise.resolve();
  const result = previous.then(job); // previous never rejects (see tail below)
  const tail = result.catch(() => {});
  tails.set(key, tail);
  tail.then(() => {
    if (tails.get(key) === tail) tails.delete(key); // nothing queued after us: clean up
  });
  return result;
}
