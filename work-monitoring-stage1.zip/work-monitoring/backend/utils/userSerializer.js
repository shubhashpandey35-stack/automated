// Decides exactly which user fields may leave the server.
// Password is never included. Location is included ONLY if the employee gave consent.
export const toPublicUser = (u) => ({
  id: String(u._id),
  name: u.name,
  email: u.email,
  profilePhoto: u.profilePhoto || "",
  role: u.role,
  status: u.status,
  lastActivity: u.lastActivity || null,
  statusUpdatedAt: u.statusUpdatedAt || null,
  // Time totals. The browser adds (now - statusSince) to the CURRENT status so numbers tick live.
  // serverTime lets the browser correct for a wrong clock on the viewer's computer.
  timeTotalsMs: {
    online: u.timeTotalsMs?.online || 0,
    inactive: u.timeTotalsMs?.inactive || 0,
    offline: u.timeTotalsMs?.offline || 0,
  },
  statusSince: u.statusUpdatedAt || u.createdAt || null,
  serverTime: Date.now(),
  locationConsent: !!u.locationConsent,
  location:
    u.locationConsent && u.location && u.location.latitude != null
      ? {
          latitude: u.location.latitude,
          longitude: u.location.longitude,
          updatedAt: u.location.updatedAt,
        }
      : null,
  createdAt: u.createdAt,
});
