// Pure functions (no database, no Express) that decide HOW status time is counted.
// Kept separate so they can be unit-tested without MongoDB.
//
// Rule that makes the numbers always correct:
//   user.timeTotalsMs.<status>  = time spent in CLOSED segments of that status
//   the CURRENT segment         = from "segment start" until now (not yet added)
//   live total of current status = timeTotalsMs[status] + (now - segmentStart)
//
// Totals are stored in milliseconds, so no rounding error builds up over many changes.

export const STATUSES = ["online", "inactive", "offline"];

const toMs = (d) => (d instanceof Date ? d.getTime() : new Date(d).getTime());

// When did the current status begin? Brand-new users start "offline" at registration time.
export const segmentStart = (user) => user.statusUpdatedAt || user.createdAt || new Date();

const totalOf = (user, key) => Number(user.timeTotalsMs?.[key]) || 0;

// Returns the fields to $set in MongoDB. Returns {} when nothing needs saving.
export function computeStatusPatch(user, nextStatus, now = new Date(), { touchActivity = false } = {}) {
  if (!STATUSES.includes(nextStatus)) throw new Error(`Unknown status: ${nextStatus}`);
  const patch = {};
  if (touchActivity) patch.lastActivity = now;

  const current = STATUSES.includes(user.status) ? user.status : "offline";
  if (current === nextStatus) return patch; // same status: only the activity time may change

  const elapsed = Math.max(0, toMs(now) - toMs(segmentStart(user)));
  patch[`timeTotalsMs.${current}`] = totalOf(user, current) + elapsed;
  patch.status = nextStatus;
  patch.statusUpdatedAt = now;
  return patch;
}

// Used once when the server starts. Nobody is connected after a restart, so everyone
// becomes offline. We only trust time up to the last thing we KNOW happened; the
// remaining gap (server was down) is counted as offline instead of inflating "online".
export function closeForRestart(user, now = new Date()) {
  const current = user.status;
  if (!STATUSES.includes(current) || current === "offline") return null;

  const start = toMs(segmentStart(user));
  const nowMs = toMs(now);
  const lastKnown =
    current === "online" && user.lastActivity ? Math.max(start, toMs(user.lastActivity)) : start;
  const confirmedEnd = Math.min(nowMs, lastKnown);

  return {
    [`timeTotalsMs.${current}`]: totalOf(user, current) + Math.max(0, confirmedEnd - start),
    "timeTotalsMs.offline": totalOf(user, "offline") + Math.max(0, nowMs - confirmedEnd),
    status: "offline",
    statusUpdatedAt: now,
  };
}
